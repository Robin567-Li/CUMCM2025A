clc,clear,close all 

format long g

t1 = 1.5;
t2 = 3.6;
false_target = [0,0,0];


for alpha = 1.17 % 1.15:0.0001:1.20  % 
    true_target = [7*cos(alpha),200+7*sin(alpha),0]   % 
    % true_target = [1.30479781554517,206.877317984545,0];
    M1 = [20000,0,2000];
    FY1 = [17800,0,1800];
    
    M1_1(1) = 20000.00 - 298.51115706 * t1;
    M1_1(2) = 0.00;
    M1_1(3) = 2000.00 - 29.85111571 * t1;
    M1_2(1) = M1_1(1) - 298.51115706 * t2;
    M1_2(2) = M1_1(2);
    M1_2(3) = M1_1(3) - 29.85111571 * t2;
    
    FY1_1(1) = 17800.00 - 120 * t1;
    FY1_1(2) = 0.00;
    FY1_1(3) = 1800.00;
    FY1_2(1) = FY1_1(1) - 120 * t2;
    FY1_2(2) = FY1_1(2);
    FY1_2(3) = FY1_1(3) - 0.5*9.80665*t2^2;
    
    t3_1 = 2;    
    while true
        M1_3(1) = M1_2(1) - 298.51115706 * t3_1;
        M1_3(2) = M1_2(2);
        M1_3(3) = M1_2(3) - 29.85111571 * t3_1;
        FY1_3(1) = FY1_2(1);
        FY1_3(2) = FY1_2(2);
        FY1_3(3) = FY1_2(3) - 3*t3_1;
        v = M1_3 - true_target; 
        PQ = FY1_3 - true_target;
        flag = norm(cross(PQ,v))/norm(v);
        if flag < 10
            t3_11 = t3_1;
            break
        end
        t3_1 = t3_1 + 0.001;
    end
    
    t3_2 = 5; 
    while true
        M1_3(1) = M1_2(1) - 298.51115706 * t3_2;
        M1_3(2) = M1_2(2);
        M1_3(3) = M1_2(3) - 29.85111571 * t3_2;
        FY1_3(1) = FY1_2(1);
        FY1_3(2) = FY1_2(2);
        FY1_3(3) = FY1_2(3) - 3*t3_2;
        flag = sqrt(sum( (M1_3-FY1_3).^2 ));
        if flag <= 10
            t3_22 = t3_2;
            break
        end
        t3_2 = t3_2 - 0.001;
    end
    t3_11
    t3_22
    duration = t3_22 - t3_11;
    if duration < 1.41 ; 
        duration
        true_target
        alpha
    end
    M1_3;
    FY1_1
    FY1_2
    FY1_3
end

